package gui;

public class Main {

    public static Frame frame;

    public static void main(String[] args) {

        frame = new Frame();
    }
}
